﻿using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

namespace Tokotech.MediaCenter.Server.Code
{
    internal static class ThumbnailCache
    {
        private static readonly Dictionary<string, byte[]> ImageDataLookup = new Dictionary<string, byte[]>();
        private static readonly Queue<string> _imageQueue = new Queue<string>(100);
        private static readonly object SyncLock = new object();

        public static void AddThumbnail(string id, byte[] thumbnailData)
        {
            lock (SyncLock)
            {
                if (_imageQueue.Count >= 100)
                {
                    var key = _imageQueue.Dequeue();

                    if (ImageDataLookup.ContainsKey(key))
                        ImageDataLookup.Remove(key);

                }
                _imageQueue.Enqueue(id);
                ImageDataLookup.Add(id, thumbnailData);
            }
        }

        public static bool TryGetThumbnail(string id, out byte[] thumbnailData)
        {
            lock (SyncLock)
            {
                if (ImageDataLookup.ContainsKey(id))
                {
                    thumbnailData = ImageDataLookup[id];
                    return true;
                }
            }
            thumbnailData = null;
            return false;
        }

        public static byte[] CreateThumbnail(int thumbnailMax, FileInfo originalImagePath)
        {
            if (originalImagePath == null) return null;

            // Loads original image from file
            using (var imgOriginal = Image.FromStream(originalImagePath.OpenRead()))
            {
                float originalHeight = imgOriginal.Height;
                float originalWidth = imgOriginal.Width;
                // Finds height and width of resized image
                int thumbnailWidth;
                int thumbnailHeight;
                if (originalHeight > originalWidth)
                {
                    thumbnailHeight = thumbnailMax;
                    thumbnailWidth = (int)((originalWidth / originalHeight) * thumbnailMax);
                }
                else
                {
                    thumbnailWidth = thumbnailMax;
                    thumbnailHeight = (int)((originalHeight / originalWidth) * thumbnailMax);
                }
                // Create new bitmap that will be used for thumbnail
                var thumbnailBitmap = new Bitmap(thumbnailWidth, thumbnailHeight);
                var resizedImage = Graphics.FromImage(thumbnailBitmap);

                // Resized image 
                resizedImage.InterpolationMode = InterpolationMode.Low;
                resizedImage.CompositingQuality = CompositingQuality.HighSpeed;
                resizedImage.SmoothingMode = SmoothingMode.HighSpeed;

                // Draw resized image
                var stream = new MemoryStream();
                resizedImage.DrawImage(imgOriginal, 0, 0, thumbnailWidth, thumbnailHeight);
                thumbnailBitmap.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                thumbnailBitmap.Dispose();
                return stream.ToArray();
            }
        }
    }
}