﻿
namespace Tokotech.MediaCenter.Server.Code
{
    public static class PlayRate
    {
        public const float FastFoward1 = 3f;
        public const float FastFoward2 = 4f;
        public const float FastFoward3 = 5f;
        public const float Pause = 1f;
        public const float Play = 2f;
        public const float Rewind1 = 6f;
        public const float Rewind2 = 7f;
        public const float Rewind3 = 8f;
        public const float SlowMotion1 = 9f;
        public const float SlowMotion2 = 10f;
        public const float SlowMotion3 = 11f;
        public const float Stop = 0f;
    }
}

