﻿using System;
using System.Diagnostics;
using System.IO;

namespace Tokotech.MediaCenter.Server.Code
{
    internal static class LogUtility
    {
        private static readonly object _syncLock = new object();
        private static string _logPath = string.Empty;

        private static void CreateLogFile()
        {
           
                if (!string.IsNullOrEmpty(_logPath)) return;

                var info = new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + Path.DirectorySeparatorChar + "MediaCenterServer");
                if (!info.Exists)
                {
                    info.Create();
                }
                var info2 = new FileInfo(info.FullName + Path.DirectorySeparatorChar + "logfile.txt");
                if (!info2.Exists)
                {
                    info2.Create();
                }
                _logPath = info2.FullName;
           
        }

        public static void LogException(Exception ex)
        {
            try
            {
                CreateLogFile();
                if (string.IsNullOrEmpty(_logPath)) return;


                lock (_syncLock)
                {
                    using (var writer = new StreamWriter(_logPath, true))
                    {
                        writer.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                        writer.WriteLine(ex.Message);
                        writer.WriteLine(ex.Source);
                        writer.WriteLine(ex.TargetSite);
                        writer.WriteLine(ex.StackTrace);
                        var trace = new StackTrace(ex);
                        if (trace.FrameCount > 0)
                        {
                            var frame = trace.GetFrame(0);
                            if (frame != null)
                            {
                                var method = frame.GetMethod();
                                writer.WriteLine(string.Format("{0}, Line {1}", method.Name, frame.GetFileLineNumber()));
                            }
                        }
                        writer.WriteLine();
                    }
                }
                if (ex.InnerException != null)
                {
                    LogException(ex.InnerException);
                }
            }
            catch (Exception)
            {
                // dont care
            }
        }

        public static void LogMessage(string message)
        {
            try
            {
                CreateLogFile();
                if (string.IsNullOrEmpty(_logPath)) return;


                lock (_syncLock)
                {
                    using (var writer = new StreamWriter(_logPath, true))
                    {
                        writer.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                        writer.WriteLine(message);
                        writer.WriteLine("");
                    }
                }
            }
            catch (Exception)
            {
                //Dont care
            }

        }
    }
}

