﻿using System;
using System.Collections.Generic;
using Microsoft.MediaCenter.Hosting;

namespace Tokotech.MediaCenter.Server.Code
{
    public class MCEAddIn : IAddInModule, IAddInEntryPoint
    {
        public void Initialize(Dictionary<string, object> appInfo, Dictionary<string, object> entryPointInfo)
        {
        }

        public void Uninitialize()
        {
            try
            {
                EndpointService.Current.TeardownService();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
            }
        }

        public void Launch(AddInHost host)
        {
            try
            {
                // System.Diagnostics.Debugger.Launch();

                if (host != null && host.ApplicationContext != null)
                {
                    host.ApplicationContext.SingleInstance = true;
                }

                var app = new Application(host);
                app.Start();

            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
        }
    }
}
