﻿
namespace Tokotech.MediaCenter.Server.Code
{
    internal static class MediaAttributes
    {
        public const string AcquisitionTime = "AcquisitionTime";
        public const string AcquisitionTimeDay = "AcquisitionTimeDay";
        public const string AcquisitionTimeMonth = "AcquisitionTimeMonth";
        public const string AcquisitionTimeYear = "AcquisitionTimeYear";
        public const string AcquisitionTimeYearMonth = "AcquisitionTimeYearMonth";
        public const string AcquisitionTimeYearMonthDay = "AcquisitionTimeYearMonthDay";
        public const string AlbumID = "AlbumID";
        public const string AlbumIDAlbumArtist = "AlbumIDAlbumArtist";
        public const string Artist = "Author";
        public const string AudioFormat = "AudioFormat";
        public const string Author = "Author";
        public const string AverageLevel = "AverageLevel";
        public const string Bitrate = "Bitrate";
        public const string BuyNow = "BuyNow";
        public const string BuyTickets = "BuyTickets";
        public const string CanonicalFileType = "CanonicalFileType";
        public const string ContentDistributorDuration = "ContentDistributorDuration";
        public const string Copyright = "Copyright";
        public const string CurrentBitrate = "CurrentBitrate";
        public const string DefaultDate = "DefaultDate";
        public const string Description = "Description";
        public const string DisplayArtist = "DisplayArtist";
        public const string DRMIndividualizedVersion = "DRMIndividualizedVersion";
        public const string DRMKeyID = "DRMKeyID";
        public const string Duration = "Duration";
        public const string FileSize = "FileSize";
        public const string FileType = "FileType";
        public const string HMEAlbumTitle = "HMEAlbumTitle";
        public const string Is_Protected = "Is_Protected";
        public const string IsVBR = "IsVBR";
        public const string LinkedFileURL = "LinkedFileURL";
        public const string MediaType = "MediaType";
        public const string MoreInfo = "MoreInfo";
        public const string PeakValue = "PeakValue";
        public const string ProviderLogoURL = "ProviderLogoURL";
        public const string ProviderURL = "ProviderURL";
        public const string RecordingTime = "RecordingTime";
        public const string RecordingTimeDay = "RecordingTimeDay";
        public const string RecordingTimeMonth = "RecordingTimeMonth";
        public const string RecordingTimeYear = "RecordingTimeYear";
        public const string RecordingTimeYearMonth = "RecordingTimeYearMonth";
        public const string RecordingTimeYearMonthDay = "RecordingTimeYearMonthDay";
        public const string ReleaseDate = "ReleaseDate";
        public const string ReleaseDateDay = "ReleaseDateDay";
        public const string ReleaseDateMonth = "ReleaseDateMonth";
        public const string ReleaseDateYear = "ReleaseDateYear";
        public const string ReleaseDateYearMonth = "ReleaseDateYearMonth";
        public const string ReleaseDateYearMonthDay = "ReleaseDateYearMonthDay";
        public const string RequestState = "RequestState";
        public const string SourceURL = "SourceURL";
        public const string SyncState = "SyncState";
        public const string SyncState2 = "SyncState2";
        public const string Title = "Title";
        public const string TrackingID = "TrackingID";
        public const string UserCustom1 = "UserCustom1";
        public const string UserCustom2 = "UserCustom2";
        public const string UserEffectiveRating = "UserEffectiveRating";
        public const string UserLastPlayedTime = "UserLastPlayedTime";
        public const string UserPlayCount = "UserPlayCount";
        public const string UserPlaycountAfternoon = "UserPlaycountAfternoon";
        public const string UserPlaycountEvening = "UserPlaycountEvening";
        public const string UserPlaycountMorning = "UserPlaycountMorning";
        public const string UserPlaycountNight = "UserPlaycountNight";
        public const string UserPlaycountWeekday = "UserPlaycountWeekday";
        public const string UserPlaycountWeekend = "UserPlaycountWeekend";
        public const string UserRating = "UserRating";
        public const string UserServiceRating = "UserServiceRating";
        public const string WMAlbumArtist = "WM/AlbumArtist";
        public const string WMAlbumTitle = "WM/AlbumTitle";
        public const string WMCategory = "WM/Category";
        public const string WMComposer = "WM/Composer";
        public const string WMConductor = "WM/Conductor";
        public const string WMContentDistributor = "WM/ContentDistributor";
        public const string WMContentGroupDescription = "WM/ContentGroupDescription ";
        public const string WMEncodingTime = "WM/EncodingTime";
        public const string WMGenre = "WM/Genre";
        public const string WMGenreID = "WM/GenreID";
        public const string WMInitialKey = "WM/InitialKey";
        public const string WMLanguage = "WM/Language";
        public const string WMLyrics = "WM/Lyrics";
        public const string WMMCDI = "WM/MCDI";
        public const string WMMediaClassPrimaryID = "WM/MediaClassPrimaryID";
        public const string WMMediaClassSecondaryID = "WM/MediaClassSecondaryID";
        public const string WMMood = "WM/Mood";
        public const string WMParentalRating = "WM/ParentalRating";
        public const string WMPartOfSet = "WM/PartOfSet";
        public const string WMPeriod = "WM/Period";
        public const string WMProtectionType = "WM/ProtectionType";
        public const string WMProvider = "WM/Provider";
        public const string WMProviderRating = "WM/ProviderRating";
        public const string WMProviderStyle = "WM/ProviderStyle";
        public const string WMPublisher = "WM/Publisher";
        public const string WMSubscriptionContentID = "WM/SubscriptionContentID";
        public const string WMSubTitle = "WM/SubTitle";
        public const string WMTrackNumber = "WM/TrackNumber";
        public const string WMUniqueFileIdentifie = "WM/UniqueFileIdentifier";
        public const string WMWMCollectionGroupID = "WM/WMCollectionGroupID";
        public const string WMWMCollectionID = "WM/WMCollectionID";
        public const string WMWMContentID = "WM/WMContentID";
        public const string WMWriter = "WM/Writer";
        public const string WMYear = "WM/Year";
    }

    internal static class MediaType
    {
        public const string Audio = "audio";
        public const string Other = "other";
        public const string Photo = "photo";
        public const string Playlist = "playlist";
        public const string Radio = "radio";
        public const string Video = "video";
    }
}


