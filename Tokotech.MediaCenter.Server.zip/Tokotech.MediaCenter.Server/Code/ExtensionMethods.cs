﻿using Microsoft.MediaCenter;
using Microsoft.MediaCenter.Hosting;

namespace Tokotech.MediaCenter.Server.Code
{
    public static class ExtensionMethods
    {
        public static MediaExperience GetMediaExperience(this AddInHost addInHost)
        {
            if ((addInHost == null) || (addInHost.MediaCenterEnvironment == null))
            {
                return null;
            }

            var mediaExperience = addInHost.MediaCenterEnvironment.MediaExperience;
            if (mediaExperience == null)
            {
                Utility.ResetMediaExperienceCache(addInHost.MediaCenterEnvironment);
                mediaExperience = addInHost.MediaCenterEnvironment.MediaExperience;
            }
            return mediaExperience;
        }
    }
}
