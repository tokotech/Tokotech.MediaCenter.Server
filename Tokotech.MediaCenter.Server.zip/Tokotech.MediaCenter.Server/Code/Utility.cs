﻿using System;
using System.Reflection;
using Microsoft.MediaCenter;

namespace Tokotech.MediaCenter.Server.Code
{
    internal static class Utility
    {
        public static void ResetMediaExperienceCache(MediaCenterEnvironment environment)
        {
            if (IsWindows7OrHigher)
            {
                try
                {
                    var field = environment.GetType().GetField("_checkedMediaExperience",
                                                               BindingFlags.NonPublic | BindingFlags.Public |
                                                               BindingFlags.Instance);
                    if (field != null)
                        field.SetValue(environment, false);
                    else
                        LogUtility.LogMessage("Warning: cannot find MediaCenterEnvironment._checkedMediaExperience field on Windows 7");
                }
                catch (Exception exception)
                {
                    LogUtility.LogMessage(
                        "Error setting MediaCenterEnvironment._checkedMediaExperience flag on Windows 7: " +
                        exception);
                }
            }
        }

        public static bool IsWindows7OrHigher
        {
            get
            {
                var oSVersion = Environment.OSVersion;
                return ((oSVersion.Version.Major == 6) && (oSVersion.Version.Minor >= 1));
            }
        }
    }
}
