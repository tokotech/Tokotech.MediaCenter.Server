﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Threading;
using Id3Tag;
using Id3Tag.HighLevel;
using Tokotech.MediaCenter.Common;
using Tokotech.MediaCenter.Common.Interfaces;
using WMPLib;
using Genre = Tokotech.MediaCenter.Common.Genre;

namespace Tokotech.MediaCenter.Server.Code
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    internal class MediaLibraryService : IMediaLibraryService
    {
        #region properties
        private static readonly Dictionary<string, Artist> ArtistCache = new Dictionary<string, Artist>();
        private static readonly Dictionary<string, Album> AlbumCache = new Dictionary<string, Album>();
        private static readonly Dictionary<string, Album> AlbumWithoutArtCache = new Dictionary<string, Album>();
        private static readonly Dictionary<string, Track> TrackCache = new Dictionary<string, Track>();
        private static readonly Dictionary<string, Genre> GenreCache = new Dictionary<string, Genre>();
        private static readonly Dictionary<string, Composer> ComposerCache = new Dictionary<string, Composer>();
        private static readonly Dictionary<string, Year> YearCache = new Dictionary<string, Year>();

        #endregion

        #region Cache

        private static void CacheArtists(IWMPPlayer4 mediaPlayer)
        {
            var artistlist = mediaPlayer.mediaCollection.getAttributeStringCollection(MediaAttributes.DisplayArtist, MediaType.Audio);

            for (var i = 0; i < artistlist.count; i++)
            {
                var artistname = artistlist.Item(i);
                if (String.IsNullOrEmpty(artistname) || ArtistCache.ContainsKey(artistname.ToLower())) continue;

                ArtistCache.Add(artistname.ToLower(), new Artist { Name = artistname });
            }
        }

        private static void CacheTrackAlbum(IWMPPlayer4 mediaPlayer)
        {
            var titles = mediaPlayer.mediaCollection.getAttributeStringCollection(MediaAttributes.Title, MediaType.Audio);

            for (var i = 0; i < titles.count; i++)
            {
                var titlename = titles.Item(i);
                if (String.IsNullOrEmpty(titlename)) continue;

                var playlist = mediaPlayer.mediaCollection.getByName(titlename);
                var media = playlist.Item[0];

                var track = GetTrack(media);
                CacheAlbums(media, track);
                CacheAlbumsWithoutArt(media);

                if (track == null) continue;

                if (!TrackCache.ContainsKey(track.Title.ToLower()))
                    TrackCache.Add(track.Title.ToLower(), track);
            }
        }

        private static void CacheAlbums(IWMPMedia wmpTrack, Track track)
        {
            var albumTitle = wmpTrack.getItemInfo(MediaAttributes.WMAlbumTitle);
            var albumId = wmpTrack.getItemInfo(MediaAttributes.AlbumID);

            if (string.IsNullOrEmpty(albumTitle))
                albumTitle = "Unknown Album";

            if (string.IsNullOrEmpty(albumId))
                albumId = "Unknown_Album";


            Album album;
            if (AlbumCache.TryGetValue(albumId, out album))
            {
                album.Tracks.Add(track);
                return;
            }

            var time = new DateTime();
            var releaseDateYear = wmpTrack.getItemInfo(MediaAttributes.ReleaseDateYear);

            if (!string.IsNullOrEmpty(releaseDateYear))
                DateTime.TryParseExact(releaseDateYear, new[] { "yyyy" }, CultureInfo.CurrentCulture.NumberFormat, DateTimeStyles.None, out time);

            album = new Album
            {
                ArtistName = wmpTrack.getItemInfo(MediaAttributes.WMAlbumArtist),
                ComposerName = wmpTrack.getItemInfo(MediaAttributes.WMComposer),
                Genre = wmpTrack.getItemInfo(MediaAttributes.WMGenre),
                ID = albumId,
                ReleaseYear = time,
                Title = albumTitle,
                AlbumArt = GetAlbumThumbnailCover(track),
                Tracks = new List<Track>()

            };

            album.Tracks.Add(track);
            AlbumCache.Add(albumId, album);
        }

        private static void CacheAlbumsWithoutArt(IWMPMedia wmpTrack)
        {
            var albumTitle = wmpTrack.getItemInfo(MediaAttributes.WMAlbumTitle);
            var albumId = wmpTrack.getItemInfo(MediaAttributes.AlbumID);

            if (string.IsNullOrEmpty(albumTitle))
                albumTitle = "Unknown Album";

            if (string.IsNullOrEmpty(albumId))
                albumId = "Unknown_Album";


            if (AlbumWithoutArtCache.ContainsKey(albumId))
                return;

            var time = new DateTime();
            var releaseDateYear = wmpTrack.getItemInfo(MediaAttributes.ReleaseDateYear);

            if (!string.IsNullOrEmpty(releaseDateYear))
                DateTime.TryParseExact(releaseDateYear, new[] { "yyyy" }, CultureInfo.CurrentCulture.NumberFormat, DateTimeStyles.None, out time);

            var album = new Album
            {
                ArtistName = wmpTrack.getItemInfo(MediaAttributes.WMAlbumArtist),
                ComposerName = wmpTrack.getItemInfo(MediaAttributes.WMComposer),
                Genre = wmpTrack.getItemInfo(MediaAttributes.WMGenre),
                ID = albumId,
                ReleaseYear = time,
                Title = albumTitle
            };

            AlbumWithoutArtCache.Add(albumId, album);

        }

        private static Track GetTrack(IWMPMedia wmpTrack)
        {
            var lpt = new DateTime();
            var str = wmpTrack.getItemInfo(MediaAttributes.UserLastPlayedTime);

            if (!string.IsNullOrEmpty(str))
                DateTime.TryParse(str, out lpt);

            double duration;
            double.TryParse(wmpTrack.getItemInfo(MediaAttributes.Duration), out duration);

            int playCount;
            int.TryParse(wmpTrack.getItemInfo(MediaAttributes.UserPlayCount), NumberStyles.Integer, null, out playCount);

            int trackNumber;
            int.TryParse(wmpTrack.getItemInfo(MediaAttributes.WMTrackNumber), NumberStyles.Integer, null, out trackNumber);

            //TEST
            //// Store the number of attributes in the current media item using attributeCount.
            //int numAttributes = wmpTrack.attributeCount;

            //// Create strings to hold each attribute name and value.
            //string atName;
            //string atValue;

            //// Loop through the attribute list.   
            //for (int i = 0; i < numAttributes; i++)
            //{
            //    // Fill the strings with the attribute information.
            //    atName = wmpTrack.getAttributeName(i);
            //    atValue = wmpTrack.getItemInfo(atName);

            //    Console.WriteLine(atName + " " + atValue);
            //}

            try
            {
                return new Track
                {
                    AlbumId = wmpTrack.getItemInfo(MediaAttributes.AlbumID),
                    AlbumName = wmpTrack.getItemInfo(MediaAttributes.WMAlbumTitle),
                    ArtistName = wmpTrack.getItemInfo(MediaAttributes.DisplayArtist),
                    CollectionID = wmpTrack.getItemInfo(MediaAttributes.WMWMCollectionID),
                    LastPlayed = lpt,
                    FilePath = wmpTrack.sourceURL,
                    Title = wmpTrack.getItemInfo(MediaAttributes.Title),
                    ComposerName = wmpTrack.getItemInfo(MediaAttributes.WMComposer),
                    PlayCount = playCount,
                    Duration = TimeSpan.FromSeconds(duration),
                    TrackNumber = trackNumber
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }
        }

        private static void CacheGenre(IWMPPlayer4 mediaPlayer)
        {
            var genres = mediaPlayer.mediaCollection.getAttributeStringCollection(MediaAttributes.WMGenre, MediaType.Audio);

            for (var i = 0; i < genres.count; i++)
            {
                var genrename = genres.Item(i);
                if (String.IsNullOrEmpty(genrename) || GenreCache.ContainsKey(genrename.ToLower())) continue;

                GenreCache.Add(genrename.ToLower(), new Genre { GenreName = genrename });
            }
        }

        private static void CacheComposere(IWMPPlayer4 mediaPlayer)
        {
            var composers = mediaPlayer.mediaCollection.getAttributeStringCollection(MediaAttributes.WMComposer, MediaType.Audio);

            for (var i = 0; i < composers.count; i++)
            {
                var composername = composers.Item(i);
                if (String.IsNullOrEmpty(composername) || ComposerCache.ContainsKey(composername.ToLower())) continue;

                ComposerCache.Add(composername.ToLower(), new Composer { ComposerName = composername });
            }
        }

        private static void CacheYear(IWMPPlayer4 mediaPlayer)
        {
            var playlist = mediaPlayer.mediaCollection.getByAttribute(MediaAttributes.MediaType, MediaType.Audio);

            for (var i = 0; i < playlist.count; i++)
            {
                var releaseDateYear = playlist.Item[i].getItemInfo(MediaAttributes.ReleaseDateYear);
                if (YearCache.ContainsKey(releaseDateYear.ToLower())) continue;
                var year = new Year { ReleaseYear = releaseDateYear };
                YearCache.Add(releaseDateYear.ToLower(), year);
            }

            YearCache.OrderByDescending(y => y.Key);
        }

        public static void CacheMediaLibrary()
        {
 
            ThreadPool.QueueUserWorkItem(delegate
            {
                WindowsMediaPlayer mediaPlayer = null;

                try
                {
                    mediaPlayer = new WindowsMediaPlayerClass();
                    
                    CacheArtists(mediaPlayer);
                    CacheGenre(mediaPlayer);
                    //CachePlaylist(mediaPlayer);
                    CacheComposere(mediaPlayer);
                    CacheYear(mediaPlayer);
                    CacheTrackAlbum(mediaPlayer);
                }
                catch (Exception exception)
                {
                    LogUtility.LogException(exception);
                    throw;
                }
                finally
                {
                    if (mediaPlayer != null)
                    {
                        mediaPlayer.close();
                    }
                }
            });
        }

        #endregion

        #region private methodes

        private static byte[] GetAlbumCover(Track track)
        {
            byte[] buffer = null;

            try
            {

                if (!string.IsNullOrEmpty(track.FilePath) && File.Exists(track.FilePath))
                {
                    var info = new FileInfo(track.FilePath);
                    var info2 = new FileInfo(string.Format("{0}{1}AlbumArt_{2}_Large.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar, track.CollectionID));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}AlbumArt_{2}_Small.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar, track.CollectionID));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}AlbumArtSmall", info.DirectoryName, System.IO.Path.DirectorySeparatorChar));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}Folder.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}ZuneAlbumArt.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar));

                    if (info2.Exists)
                    {
                        using (var stream = info2.OpenRead())
                        {
                            var buffer2 = new byte[stream.Length];
                            stream.Read(buffer2, 0, (int)stream.Length);
                            return  buffer2;
                        }
                    }

                }

                if (File.Exists(track.FilePath))
                {
                    var fileStream = new FileStream(track.FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    try
                    {
                        var container = new Id3TagManager().ReadV2Tag(fileStream);
                        if (container != null)
                        {
                            var frame = container.SearchFrame("APIC");
                            if (frame != null)
                                buffer = FrameUtilities.ConvertToPictureFrame(frame).PictureData.ToArray();
                        }
                    }
                    catch (Id3TagException)
                    { }
                    finally
                    {
                        fileStream.Dispose();
                    }
                }

                if (buffer == null)
                {
                    try
                    {
                        var info2 = new FileInfo(string.Format("{0}{3}{1}{3}{2}{3}NoIcon.jpg", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                                                                                                "Tokotech", "MediaCenter Server",
                                                                                                Path.DirectorySeparatorChar));

                        if (info2.Exists)
                        {
                            using (var stream = info2.OpenRead())
                            {
                                var buffer2 = new byte[stream.Length];
                                stream.Read(buffer2, 0, (int)stream.Length);
                                buffer = buffer2;
                            }
                        }
                    }
                    catch { }
                }

                return buffer;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }

        }

        private static byte[] GetAlbumThumbnailCover(Track track)
        {
            byte[] buffer = null;

            try
            {

                if (!string.IsNullOrEmpty(track.FilePath) && File.Exists(track.FilePath))
                {
                    var info = new FileInfo(track.FilePath);
                    var info2 = new FileInfo(string.Format("{0}{1}AlbumArt_{2}_Large.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar, track.CollectionID));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}AlbumArt_{2}_Small.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar, track.CollectionID));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}AlbumArtSmall", info.DirectoryName, System.IO.Path.DirectorySeparatorChar));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}Folder.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar));

                    if (!info2.Exists)
                        info2 = new FileInfo(string.Format("{0}{1}ZuneAlbumArt.jpg", info.DirectoryName, System.IO.Path.DirectorySeparatorChar));

                    if (info2.Exists)
                    {
                        return ThumbnailCache.CreateThumbnail(100, info2);
                    }

                }


                if (File.Exists(track.FilePath))
                {
                    var fileStream = new FileStream(track.FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    try
                    {
                        var container = new Id3TagManager().ReadV2Tag(fileStream);
                        if (container != null)
                        {
                            var frame = container.SearchFrame("APIC");
                            if (frame != null)
                                buffer = FrameUtilities.ConvertToPictureFrame(frame).PictureData.ToArray();
                        }
                    }
                    catch (Id3TagException)
                    { }
                    finally
                    {
                        fileStream.Dispose();
                    }
                }

                if (buffer == null)
                {
                    try
                    {
                        var info2 = new FileInfo(string.Format("{0}{3}{1}{3}{2}{3}NoIcon.jpg", Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                                                                                                "Tokotech", "MediaCenter Server",
                                                                                                Path.DirectorySeparatorChar));

                        return ThumbnailCache.CreateThumbnail(100, info2);
                       
                    }
                    catch { }
                }
                return buffer;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return null;
            }

        }

        #endregion

        // NOT USED
        public IEnumerable<Track> GetCurrentPlayList()
        {
            var list = new List<Track>();
            WindowsMediaPlayer mediaPlayer = new WindowsMediaPlayerClass();

            for (var count = 0; count <= mediaPlayer.currentPlaylist.count; count++)
            {
                var media = mediaPlayer.currentPlaylist.Item[count];
                var track = new Track { Title = media.name };
                list.Add(track);
            }

            return list;
        }

        #region public methodes

        public System.Version GetServerVersion()
        {
            return Assembly.GetExecutingAssembly().GetName().Version;
        }

        public string GetServicesName()
        {
            return Assembly.GetExecutingAssembly().GetName().Name;
        }

        public void Ping()
        { }

        #endregion

        #region Artist

        public IEnumerable<Artist> GetArtists()
        {
            IEnumerable<Artist> enumerable;
            try
            {
                enumerable = ArtistCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;


        }

        public IEnumerable<char> GetArtistsGroupList()
        {
            IEnumerable<char> enumerable;
            try
            {
                enumerable = (from a in ArtistCache.Values
                              select a.Name[0]).Distinct();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public IEnumerable<Artist> GetArtistsGroup(string startswith)
        {
            IEnumerable<Artist> enumerable;
            try
            {
                enumerable = from a in ArtistCache.Values
                             where a.Name.StartsWith(startswith)
                             select a;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public int GetArtistCount()
        {
            int count;
            try
            {
                count = ArtistCache.Count;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return count;
        }

        public IEnumerable<Artist> GetArtistRange(int index, int count)
        {
            IEnumerable<Artist> range;
            try
            {
                range = ArtistCache.Values.ToList().GetRange(index, count);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return range;
        }

        public IEnumerable<Album> GetAlbumsByArtist(Artist artist)
        {
            return from al in AlbumCache.Values
                   where al.ArtistName == artist.Name
                   select al;
        }

        #endregion

        #region Albums

        public Album GetAlbum(Album album)
        {
            return (from a in AlbumCache.Values
                    where a.ID == album.ID
                    select a).FirstOrDefault();
        }

        public IEnumerable<Album> GetAlbums()
        {
            IEnumerable<Album> enumerable;
            try
            {
                enumerable = AlbumCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public Byte[] GetAlbumArtByAlbum(Album album)
        {
            var track = (from a in TrackCache.Values
                         where a.AlbumId == album.ID
                         select a).FirstOrDefault();

            if (track == null)
            {
                track = (from a in TrackCache.Values
                         where a.AlbumName == album.ID & a.ArtistName == album.ArtistName
                         select a).FirstOrDefault();
            }

            if (track != null)
                return GetAlbumCover(track);

            return (from a in AlbumCache.Values
                    where a.ID == album.ID
                    select a.AlbumArt).FirstOrDefault();

        }

        public IEnumerable<Album> GetAlbumsWithoutArt()
        {
            IEnumerable<Album> enumerable;
            try
            {
                enumerable = AlbumWithoutArtCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;

        }

        public IEnumerable<char> GetAlbumsGroupList()
        {
            IEnumerable<char> enumerable;
            try
            {
                enumerable = (from a in AlbumCache.Values
                              select a.Title[0]).Distinct();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public IEnumerable<Album> GetAlbumGroup(string startswith)
        {
            IEnumerable<Album> enumerable;
            try
            {
                enumerable = from a in AlbumCache.Values
                             where a.Title.StartsWith(startswith)
                             select a;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public int GetAlbumsCount()
        {
            int count;
            try
            {
                count = AlbumCache.Count;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return count;
        }

        public IEnumerable<Album> GetAlbumsRange(int index, int count)
        {
            IEnumerable<Album> range;
            try
            {
                range = AlbumCache.Values.ToList().GetRange(index, count);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return range;
        }

        public Byte[] GetAlbumArtByTrack(Track track)
        {
            return GetAlbumCover(track);
        }

        #endregion

        #region Genres

        public IEnumerable<Genre> GetGenres()
        {
            IEnumerable<Genre> enumerable;
            try
            {
                enumerable = GenreCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public int GetGenresCount()
        {
            int count;
            try
            {
                count = GenreCache.Count;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return count;
        }

        public IEnumerable<Genre> GetGenresRange(int index, int count)
        {
            IEnumerable<Genre> range;
            try
            {
                range = GenreCache.Values.ToList().GetRange(index, count);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return range;
        }

        public IEnumerable<Album> GetAlbumsByGenre(Genre genre)
        {
            return from album in AlbumCache.Values
                   where album.Genre == genre.GenreName
                   select album;
        }

        #endregion

        #region Tracks

        public Track GetTrack(Track track)
        {
            return (from t in TrackCache.Values
                    where t.Title == track.Title
                    select t).FirstOrDefault();
        }

        public IEnumerable<Track> GetTracks()
        {
            IEnumerable<Track> enumerable;
            try
            {
                enumerable = TrackCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public int GetTracksCount()
        {
            int count;
            try
            {
                count = TrackCache.Count;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return count;
        }

        public IEnumerable<Track> GetTracksRange(int index, int count)
        {
            IEnumerable<Track> range;
            try
            {
                range = TrackCache.Values.ToList().GetRange(index, count);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return range;
        }

        #endregion

        //#region Playlist

        //public IEnumerable<Playlist> GetPlaylists()
        //{
        //    IEnumerable<Playlist> enumerable;
        //    try
        //    {
        //        enumerable = PlaylistCache.Values.ToList();
        //    }
        //    catch (Exception exception)
        //    {
        //        //.LogException(exception);
        //        throw;
        //    }
        //    return enumerable;
        //}

        //public int GetPlaylistsCount()
        //{
        //    int count;
        //    try
        //    {
        //        count = PlaylistCache.Count;
        //    }
        //    catch (Exception exception)
        //    {
        //        //LogUtility.LogException(exception);
        //        throw;
        //    }
        //    return count;
        //}

        //public IEnumerable<Playlist> GetPlaylistsRange(int index, int count)
        //{
        //    IEnumerable<Playlist> range;
        //    try
        //    {
        //        range = PlaylistCache.Values.ToList().GetRange(index, count);
        //    }
        //    catch (Exception exception)
        //    {
        //        // LogUtility.LogException(exception);
        //        throw;
        //    }
        //    return range;
        //}

        //public IEnumerable<Album> GetAlbumsByPlaylist(Composer composer)
        //{
        //    return from album in AlbumCache.Values
        //           where album.ComposerName == composer.ComposerName
        //           select album;
        //}

        //#endregion

        #region Composers

        public IEnumerable<Composer> GetComposers()
        {
            IEnumerable<Composer> enumerable;
            try
            {
                enumerable = ComposerCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public int GetComposersCount()
        {
            int count;
            try
            {
                count = ComposerCache.Count;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return count;
        }

        public IEnumerable<Composer> GetComposersRange(int index, int count)
        {
            IEnumerable<Composer> range;
            try
            {
                range = ComposerCache.Values.ToList().GetRange(index, count);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return range;
        }

        public IEnumerable<Album> GetAlbumsByComposer(Composer composer)
        {
            return from album in AlbumCache.Values
                   where album.ComposerName == composer.ComposerName
                   select album;
        }

        #endregion

        #region Year

        public IEnumerable<Year> GetYears()
        {
            IEnumerable<Year> enumerable;
            try
            {
                enumerable = YearCache.Values.ToList();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return enumerable;
        }

        public int GetYearsCount()
        {
            int count;
            try
            {
                count = YearCache.Count;
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return count;
        }

        public IEnumerable<Year> GetYearsRange(int index, int count)
        {
            IEnumerable<Year> range;
            try
            {
                range = YearCache.Values.ToList().GetRange(index, count);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return range;
        }

        public IEnumerable<Album> GetAlbumsByYear(Year year)
        {
            return from album in AlbumCache.Values
                   where album.ReleaseYear.Year.ToString() == year.ReleaseYear
                   select album;
        }

        #endregion

        #region MostPlayed

        public IEnumerable<Track> GetLatestPlayedTracks()
        {
            return (from track in TrackCache.Values
                    orderby track.LastPlayed descending
                    select track).Take(10);
        }

        public IEnumerable<Track> GetMostPlayedTracks()
        {
            return (from track in TrackCache.Values
                    orderby track.PlayCount descending
                    select track).Take(10);
        }

        #endregion

    }
}
