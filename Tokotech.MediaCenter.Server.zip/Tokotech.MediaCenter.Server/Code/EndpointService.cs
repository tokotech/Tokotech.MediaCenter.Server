﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using Tokotech.MediaCenter.Common.Interfaces;

namespace Tokotech.MediaCenter.Server.Code
{
    internal class EndpointService
    {
        private static readonly EndpointService _current = new EndpointService();
        private readonly ServiceHost _libraryServiceHost = new ServiceHost(typeof(MediaLibraryService), new[] { new Uri("http://localhost:8585/MediaLibrary") });
        private readonly ServiceHost _playbackServiceHost = new ServiceHost(typeof(MediaPlaybackService), new[] { new Uri("http://localhost:8585/MediaPlayback") });

        private EndpointService()
        {
        }

        public void InitializeService()
        {
            _libraryServiceHost.AddServiceEndpoint(typeof(IMediaLibraryService), new BasicHttpBinding(BasicHttpSecurityMode.None), string.Empty);
            _playbackServiceHost.AddServiceEndpoint(typeof(IMediaPlaybackService), new BasicHttpBinding(BasicHttpSecurityMode.None), string.Empty);
            var item = new ServiceMetadataBehavior
            {
                HttpGetEnabled = true
            };
            _libraryServiceHost.Description.Behaviors.Add(item);
            _libraryServiceHost.AddServiceEndpoint(typeof(IMetadataExchange), MetadataExchangeBindings.CreateMexHttpBinding(), "mex");
            var behavior2 = new ServiceMetadataBehavior
            {
                HttpGetEnabled = true
            };
            _playbackServiceHost.Description.Behaviors.Add(behavior2);
            _playbackServiceHost.AddServiceEndpoint(typeof(IMetadataExchange), MetadataExchangeBindings.CreateMexHttpBinding(), "mex");
            _libraryServiceHost.Open();
            _playbackServiceHost.Open();
        }

        public void TeardownService()
        {
            _libraryServiceHost.Close();
            _playbackServiceHost.Close();
        }

        public static EndpointService Current
        {
            get
            {
                return _current;
            }
        }
    }
}
