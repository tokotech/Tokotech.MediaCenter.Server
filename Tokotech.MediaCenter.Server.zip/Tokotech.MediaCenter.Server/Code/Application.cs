﻿using System;
using System.Diagnostics;
using System.Threading;
using Microsoft.MediaCenter;
using Microsoft.MediaCenter.Hosting;
using Microsoft.MediaCenter.UI;

namespace Tokotech.MediaCenter.Server.Code
{
    public class Application : ModelItem
    {
        private readonly AddInHost _host;
        public static AddInHost mediaCenterHost;

        public Application(AddInHost host)
        {
            this._host = host;
        }

        public MediaCenterEnvironment MediaCenterEnvironment
        {
            get
            {
                if (_host == null) return null;
                return _host.MediaCenterEnvironment;
            }
        }

        internal void Start()
        {

            mediaCenterHost = _host;

            try
            {
                LogUtility.LogMessage("Starting");
                LogUtility.LogMessage("CacheMediaLibrary");
                MediaLibraryService.CacheMediaLibrary();
                //PlaylistService.Current.InitializeService();
                LogUtility.LogMessage("WSInitializeService");
                EndpointService.Current.InitializeService();
                
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                DialogTest(exception.Message);
            }

            while (true)
            {
                Thread.Sleep(500);
            }

            LogUtility.LogMessage("Exiting");
        }

        public void DialogTest(string strClickedText)
        {
            const int timeout = 5;
            const bool modal = true;
            const string caption = "Tokomedia Error";

            if (_host != null)
            {
                MediaCenterEnvironment.Dialog(strClickedText,
                                              caption,
                                              new object[] { DialogButtons.Ok },
                                              timeout,
                                              modal,
                                              null,
                                              delegate { });
            }
            else
            {
                Debug.WriteLine("DialogTest");
            }
        }
    }
}