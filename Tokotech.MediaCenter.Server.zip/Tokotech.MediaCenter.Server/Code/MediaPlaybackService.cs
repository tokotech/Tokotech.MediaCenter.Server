﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using CoreAudioApi;
using Tokotech.MediaCenter.Common;
using Tokotech.MediaCenter.Common.Interfaces;

namespace Tokotech.MediaCenter.Server.Code
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class MediaPlaybackService : IMediaPlaybackService
    {
        #region private

        private static Track GetNowPlaying()
        {
            var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

            if ((mediaExperience == null) || (mediaExperience.Transport == null))
                return null;

            var mediaMetadata = mediaExperience.MediaMetadata;
            var track = new Track
            {
                ArtistName = mediaMetadata.ContainsKey("TrackArtist") ? mediaMetadata["TrackArtist"].ToString() : string.Empty,
                FilePath = mediaMetadata.ContainsKey("Uri") ? mediaMetadata["Uri"].ToString() : string.Empty,
                Title = mediaMetadata.ContainsKey("TrackTitle") ? mediaMetadata["TrackTitle"].ToString() : string.Empty,
                AlbumName = mediaMetadata.ContainsKey("AlbumTitle") ? mediaMetadata["AlbumTitle"].ToString() : string.Empty,
            };

            var result = 0;
            if (mediaMetadata.ContainsKey("TrackDuration"))
                int.TryParse(mediaMetadata["TrackDuration"].ToString(), out result);

            track.Duration = new TimeSpan(0, 0, result);
            var num2 = 0;

            if (mediaMetadata.ContainsKey("TrackNumber"))
                int.TryParse(mediaMetadata["TrackNumber"].ToString(), out num2);

            track.TrackNumber = num2;
            return track;
        }

        private static TimeSpan GetPlaybackPosition()
        {
            var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

            if ((mediaExperience != null) && (mediaExperience.Transport != null))
                return mediaExperience.Transport.Position;

            return TimeSpan.MinValue;
        }

        private static PlaybackState GetPlaybackState()
        {
            var mediaExperience = Application.mediaCenterHost.GetMediaExperience();
            if ((mediaExperience == null) || (mediaExperience.Transport == null))
                return PlaybackState.Unknown;

            var transport = mediaExperience.Transport;
            return GetPlaybackStateFromPlayRate(transport.PlayRate);
        }

        private static PlaybackState GetPlaybackStateFromPlayRate(float playRate)
        {
            if (playRate == 3f)
                return PlaybackState.FastFoward;
            if (playRate == 4f)
                return PlaybackState.FastFoward2;
            if (playRate == 5f)
                return PlaybackState.FastFoward3;
            if (playRate == 1f)
                return PlaybackState.Pause;
            if (playRate == 2f)
                return PlaybackState.Play;
            if (playRate == 6f)
                return PlaybackState.Rewind;
            if (playRate == 7f)
                return PlaybackState.Rewind2;
            if (playRate == 8f)
                return PlaybackState.Rewind3;
            if (playRate == 9f)
                return PlaybackState.SlowMotion;
            if (playRate == 10f)
                return PlaybackState.SlowMotion2;
            if (playRate == 11f)
                return PlaybackState.SlowMotion3;

            return playRate == 0f ? PlaybackState.Stop : PlaybackState.Unknown;
        }

        private static List<Track> ShuffelList(IEnumerable<Track> trackQueue)
        {
            var oldtrackQueue = trackQueue.ToList();

            var randomList = new List<Track>();
            var r = new Random();

            while (oldtrackQueue.Count > 0)
            {
                var randomIndex = r.Next(0, oldtrackQueue.Count);
                randomList.Add(oldtrackQueue[randomIndex]); //add it to the new, random list
                oldtrackQueue.RemoveAt(randomIndex); //remove to avoid duplicates
            }

            return randomList; //return the new random list
        }

        private static double GetVolumePercent()
        {
            return Audio.MasterVolume;
        }

        private MediaLibraryService LibraryService = new MediaLibraryService();

        //private void LoadPlaylist(IEnumerable<Track> trackQueue)
        //{
        //    try
        //    {
        //        if (Application.MediaCenterHost.MediaCenterEnvironment != null)
        //        {
        //            var media = PlaylistService.Current.CreatePlaylist(Guid.NewGuid().ToString(), trackQueue);
        //            Application.MediaCenterHost.MediaCenterEnvironment.PlayMedia(Microsoft.MediaCenter.MediaType.Audio, media, false);
        //        }
        //    }
        //    catch (Exception exception)
        //    {
        //        LogUtility.LogException(exception);
        //        throw;
        //    }
        //}

        #endregion

        #region Playcontrols

        public IEnumerable<Track> GetCurrentPlaylist()
        {
            var list = new List<Track>();

            var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

            if ((mediaExperience == null) || (mediaExperience.Transport == null))
                return null;

            var mediaMetadata = mediaExperience.MediaMetadata;

            foreach (var item in mediaMetadata.Keys)
            {
                try
                {
                    System.Diagnostics.Debug.WriteLine(item);
                }
                catch
                {
                    //Dont care
                }

            }

            return list;

        }

        public MediaState GetMediaState()
        {
            MediaState state2;
            try
            {
                state2 = new MediaState
                {
                    AlbumName = "",
                    ArtistName = "",
                    CurrentTrack = GetNowPlaying(),
                    PlaybackState = GetPlaybackState(),
                    PlaybackPosition = GetPlaybackPosition(),
                    CurrentTime = DateTime.Now,
                    Volume = GetVolumePercent()
                };
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return state2;
        }

        public MediaState NextTrack()
        {
            MediaState mediaState;
            try
            {
                var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

                if ((mediaExperience != null) && (mediaExperience.Transport != null))
                    mediaExperience.Transport.SkipForward();

                mediaState = GetMediaState();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return mediaState;
        }

        public MediaState Play()
        {
            MediaState mediaState;
            try
            {
                var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

                if ((mediaExperience != null) && (mediaExperience.Transport != null))
                    mediaExperience.Transport.PlayRate = 2f;

                mediaState = GetMediaState();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;

            }
            return mediaState;
        }

        public MediaState Pause()
        {
            MediaState mediaState;
            try
            {
                var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

                if ((mediaExperience != null) && (mediaExperience.Transport != null))
                    mediaExperience.Transport.PlayRate = 1f;

                mediaState = GetMediaState();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return mediaState;
        }

        public MediaState PrevTrack()
        {
            MediaState mediaState;
            try
            {
                var mediaExperience = Application.mediaCenterHost.GetMediaExperience();

                if ((mediaExperience != null) && (mediaExperience.Transport != null))
                    mediaExperience.Transport.SkipBack();

                mediaState = GetMediaState();
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
                throw;
            }
            return mediaState;
        }

        public MediaState SetVolume(double volume)
        {
            Audio.MasterVolume = (float)volume;
            return GetMediaState();
        }

        public void Ping()
        {
        }

        #endregion

        #region Play

        public MediaState PlayAll(bool shuffel)
        {
            var albums = LibraryService.GetTracks();
            PlayTracks(albums, false, shuffel);
            return GetMediaState();
        }

        private void PlayTracks(IEnumerable<Track> trackQueue, bool enqueue, bool shuffel)
        {
            try
            {
                if (Application.mediaCenterHost.MediaCenterEnvironment != null)
                {
                    List<Track> newtrackQueue;
                    if (shuffel)
                        newtrackQueue = ShuffelList(trackQueue);
                    else
                    {
                        newtrackQueue = trackQueue as List<Track>;
                        if (newtrackQueue != null)
                            newtrackQueue.Sort((t1, t2) => t1.TrackNumber.CompareTo(t2.TrackNumber));
                    }

                    var addToQueue = enqueue;
                    if (newtrackQueue != null)
                    {
                        if (!addToQueue)   // Clear queue
                            Application.mediaCenterHost.MediaCenterEnvironment.PlayMedia(Microsoft.MediaCenter.MediaType.Audio, null, addToQueue);

                        foreach (var track in newtrackQueue)
                        {
                            Application.mediaCenterHost.MediaCenterEnvironment.PlayMedia(Microsoft.MediaCenter.MediaType.Audio, track.FilePath, addToQueue);
                            addToQueue = true;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
            }
        }

        private void PlayTracks<T>(Func<T, IEnumerable<Album>> getalbums, T category, bool enqueue, bool shuffel)
        {
            var albums = getalbums(category);
            var addToQueue = enqueue;

 
            foreach (var album in albums)
            {
                PlayTracks(album.Tracks, addToQueue, shuffel);
                addToQueue = true;
            }
        }

  
        public MediaState PlayArtist(Artist artist, bool enqueue, bool shuffel)
        {
            PlayTracks<Artist>(LibraryService.GetAlbumsByArtist, artist, enqueue, shuffel);
            return GetMediaState(); ;
        }
     
        public MediaState PlayAlbum(Album album, bool enqueue, bool shuffel)
        {
            var _album = LibraryService.GetAlbum(album);
            PlayTracks(_album.Tracks, enqueue, shuffel);
            return GetMediaState();
        }

        public MediaState PlayGenre(Genre genre, bool enqueue, bool shuffel)
        {
            PlayTracks<Genre>(LibraryService.GetAlbumsByGenre, genre, enqueue, shuffel);
            return GetMediaState();
        }

        //public MediaState PlayPlaylist(Track track, bool enqueue, bool shuffel)
        //{
        //}

        public MediaState PlayTrack(Track track, bool enqueue)
        {
            try
            {
                Application.mediaCenterHost.MediaCenterEnvironment.PlayMedia(Microsoft.MediaCenter.MediaType.Audio, track.FilePath, enqueue);
            }
            catch (Exception exception)
            {
                LogUtility.LogException(exception);
            }
            return GetMediaState();
        }

        public MediaState PlayComposer(Composer composer, bool enqueue, bool shuffel)
        {
             PlayTracks<Composer>(LibraryService.GetAlbumsByComposer, composer, enqueue, shuffel);
             return GetMediaState();
        }

        public MediaState PlayYear(Year year, bool enqueue, bool shuffel)
        {
            PlayTracks<Year>(LibraryService.GetAlbumsByYear, year, enqueue, shuffel);
            return GetMediaState();
        }

        #endregion
    }
}


